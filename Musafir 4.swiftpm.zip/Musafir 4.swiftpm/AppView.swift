

import SwiftUI

@main
struct AppView: App {
    var body: some Scene {
        WindowGroup {
            SplashView()
        }
    } 
}

